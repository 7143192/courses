package com.example.bookstorebackend2.constant;

public class SolrConstant {
    public static final String COLLECTION_NAME = "mybookstore";
    public static final String DESCRIPTION_NAME = "keyword";
}
