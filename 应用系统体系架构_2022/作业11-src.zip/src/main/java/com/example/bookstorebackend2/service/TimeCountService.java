package com.example.bookstorebackend2.service;

public interface TimeCountService {
    long setStartTime();
    long setEndTime();
}
