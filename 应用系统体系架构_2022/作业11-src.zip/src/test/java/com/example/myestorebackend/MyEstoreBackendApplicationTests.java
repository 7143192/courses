package com.example.myestorebackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyEstoreBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
