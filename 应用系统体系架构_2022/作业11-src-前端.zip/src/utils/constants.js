export const BaseUrl = "https://localhost:8443/";
export const WsUrl = "ws://localhost:8080/websocket/";
export const MicroUrl = "http://localhost:8090/search/";
