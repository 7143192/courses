import logo from './logo.svg';
import BasicRoute from './Router';
import './App.css';

function App() {
  return (
    <BasicRoute/>
  );
}

export default App;
