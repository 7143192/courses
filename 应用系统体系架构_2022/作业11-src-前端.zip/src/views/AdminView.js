import React from 'react';
import AdminPage from '../components/AdminMainPage/AdminPage';

class AdminView extends React.Component{
    render(){
        return (
            <AdminPage/>
        );
    }
}

export default AdminView;
