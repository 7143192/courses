package com.example.dentistbackend.dao;
import com.example.dentistbackend.entity.Department;
import java.util.List;
public interface DepartmentDao {
    List<Department> getDepartments();
}
