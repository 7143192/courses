package com.example.dentistbackend.service;
import com.example.dentistbackend.entity.Department;
import java.util.List;
public interface DepartmentService {
    List<Department> getDepartments();
}
