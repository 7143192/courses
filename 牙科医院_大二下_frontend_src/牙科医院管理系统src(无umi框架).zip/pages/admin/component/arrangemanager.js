import React from "react";

export default class Arrangemanager extends React.Component{
  render() {
    return (
      <div>
        3
      </div>
    );
  }
}
