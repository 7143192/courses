import React from "react";
import Home from "./home";


export default class Index extends React.Component {
  // window.onbeforeunload = () => {
  //   // 这里写
  //
  // }

  render() {
    return (
      <Home/>
    )
  }
}


