#ifndef EVALSTATE_H
#define EVALSTATE_H

#endif // EVALSTATE_H
